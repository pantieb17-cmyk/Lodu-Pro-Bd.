
    let users = JSON.parse(localStorage.getItem('ludo_users')) || [];
    let matches = JSON.parse(localStorage.getItem('ludo_matches')) || [];
    let depRequests = JSON.parse(localStorage.getItem('ludo_dep_req')) || [];
    let witRequests = JSON.parse(localStorage.getItem('ludo_wit_req')) || [];
    let winResults = JSON.parse(localStorage.getItem('ludo_win_results')) || [];
    let appNotice = localStorage.getItem('ludo_app_notice') || "🥀লুডু🥀পোরো🥀বিডি🥀তে🥀সাগতম🥀";
    let depositNumber = localStorage.getItem('ludo_deposit_num') || "01963314623";
    let musicConfig = JSON.parse(localStorage.getItem('ludo_music_config')) || { isEnabled: false, url: "" };

    let currentUserEmail = null;
    let selectedDepMethod = "";
    let selectedWitMethod = "";
    let tempScreenshotBase64 = "";

    // সুন্দর মেয়ে কণ্ঠ নিশ্চিত করতে ভয়েস লোড করা
    let synth = window.speechSynthesis;
    function speakWelcome(userName) {
        if (synth) {
            synth.cancel(); // আগের কথা বন্ধ করা
            const text = userName + ", আমাদের Lodu Pro Bd তে আপনাকে স্বাগতম।";
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = 'bn-BD';
            
            // ক্লিয়ার মেয়ে কণ্ঠে কথা বলার জন্য সেটিংস
            let voices = synth.getVoices();
            let selectedVoice = voices.find(v => v.lang.includes('bn') && v.name.toLowerCase().includes('female')) || 
                                voices.find(v => v.lang.includes('bn'));
            
            if (selectedVoice) utterance.voice = selectedVoice;
            utterance.pitch = 1.3; // মেয়ে কণ্ঠের মিষ্টতা বাড়ানোর জন্য
            utterance.rate = 0.9;  // কথা ক্লিয়ার করার জন্য সামান্য ধীরে
            utterance.volume = 1.0;
            
            synth.speak(utterance);
        }
    }

    function handleLogin() {
        const email = document.getElementById('log-email').value.trim();
        const pass = document.getElementById('log-pass').value.trim();
        const user = users.find(u => u.email === email && u.pass === pass);
        if(user) {
            if(user.isBanned) return alert("আপনার আইডিটি ব্যান করা হয়েছে!");
            currentUserEmail = email;
            
            // ভয়েস মেসেজ চালু করা
            speakWelcome(user.name);

            document.getElementById('auth-page').style.display = 'none';
            document.getElementById('main-app').style.display = 'block';
            document.getElementById('welcome-text').innerText = "স্বাগতম, " + user.name.toUpperCase() + "!";
            
            updateUI(); 
            showSection('home');
            handleGlobalMusicSync();
        } else alert("Wrong ID or Password!");
    }

    function showSection(id) {
        document.querySelectorAll('.page-section').forEach(s => s.classList.remove('active'));
        document.getElementById(id).classList.add('active');
        if(id === 'home') {
            document.getElementById('app-notice-text').innerText = appNotice;
        }
        if(id === 'admin-panel') renderAdminData();
        if(id === 'result') populateMatchDropdown();
    }

    function handleGlobalMusicSync() {
        const player = document.getElementById('global-audio-player');
        const icon = document.getElementById('music-playing-icon');
        const config = JSON.parse(localStorage.getItem('ludo_music_config')) || { isEnabled: false, url: "" };

        if(config.isEnabled && config.url) {
            if(player.src !== config.url) player.src = config.url;
            player.play().then(() => {
                if(icon) icon.style.display = 'block';
            }).catch(e => console.log("Interaction required for audio"));
        } else {
            player.pause();
            if(icon) icon.style.display = 'none';
        }
    }

    // অটোমেটিক সিনক্রোনাইজেশন
    setInterval(handleGlobalMusicSync, 5000);

    function setNav(el) {
        document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active-nav'));
        el.classList.add('active-nav');
    }

    function showReg() { document.getElementById('login-form').style.display='none'; document.getElementById('reg-form').style.display='block'; }
    function showLog() { document.getElementById('login-form').style.display='block'; document.getElementById('reg-form').style.display='none'; }

    function handleRegister() {
        const name = document.getElementById('reg-name').value.trim();
        const email = document.getElementById('reg-email').value.trim();
        const pass = document.getElementById('reg-pass').value.trim();
        if(name && email && pass) {
            if(users.find(u => u.email === email)) return alert("ID Already Exists!");
            users.push({ name, email, pass, mainBalance: 0, gamingBalance: 0, joined: [], isBanned: false });
            saveData(); alert("Success! Please Login."); showLog();
        }
    }

    function handleLogout() {
        currentUserEmail = null;
        document.getElementById('main-app').style.display = 'none';
        document.getElementById('auth-page').style.display = 'flex';
        alert("লগআউট সফল হয়েছে!");
    }

    function handleTransfer() {
        const amt = parseInt(document.getElementById('home-transfer-amount').value);
        const user = users.find(u => u.email === currentUserEmail);
        if(!amt || amt <= 0) return alert("সঠিক পরিমাণ লিখুন!");
        if((user.mainBalance || 0) >= amt) {
            user.mainBalance -= amt;
            user.gamingBalance = (user.gamingBalance || 0) + amt;
            saveData(); updateUI(); alert("Transfer Successful!");
            document.getElementById('home-transfer-amount').value = "";
        } else alert("Insufficient Main Balance!");
    }

    function populateMatchDropdown() {
        const select = document.getElementById('res-match-select');
        select.innerHTML = '<option value="">ম্যাচ নির্বাচন করুন</option>';
        matches.forEach(m => {
            select.innerHTML += `<option value="${m.name}">${m.name}</option>`;
        });
    }

    function previewScreenshot(event) {
        const reader = new FileReader();
        reader.onload = function(){
            const output = document.getElementById('screenshot-preview');
            output.src = reader.result;
            output.style.display = "block";
            tempScreenshotBase64 = reader.result;
        };
        reader.readAsDataURL(event.target.files[0]);
    }

    function submitWinResult() {
        const matchName = document.getElementById('res-match-select').value;
        if(!matchName || !tempScreenshotBase64) return alert("ম্যাচ এবং স্ক্রিনশট দুটিই প্রয়োজন!");
        
        winResults.push({
            user: currentUserEmail,
            match: matchName,
            img: tempScreenshotBase64,
            date: new Date().toLocaleString()
        });
        
        saveData();
        alert("Result Submitted Successfully!");
        
        document.getElementById('res-match-select').value = "";
        document.getElementById('screenshot-preview').style.display = "none";
        tempScreenshotBase64 = "";
    }

    function openDeposit(method) {
        selectedDepMethod = method;
        document.querySelectorAll('.bal-box').forEach(el => el.classList.remove('selected-card'));
        if(method === 'bKash') document.getElementById('dep-bkash').classList.add('selected-card');
        if(method === 'Nagad') document.getElementById('dep-nagad').classList.add('selected-card');
        
        document.getElementById('deposit-form').style.display = 'block';
        document.getElementById('dep-title').innerText = method + " DEPOSIT";
        document.getElementById('display-dep-num').innerText = depositNumber;
    }

    function openWithdraw(method) {
        selectedWitMethod = method;
        document.querySelectorAll('.bal-box').forEach(el => el.classList.remove('selected-card'));
        if(method === 'bKash') document.getElementById('wit-bkash').classList.add('selected-card');
        if(method === 'Nagad') document.getElementById('wit-nagad').classList.add('selected-card');
        
        document.getElementById('withdraw-form').style.display = 'block';
        document.getElementById('wit-title').innerText = method + " WITHDRAW";
    }

    function submitDeposit() {
        const amt = document.getElementById('dep-amount').value;
        const trx = document.getElementById('dep-trxid').value;
        if(amt > 0 && trx) {
            depRequests.push({ userEmail: currentUserEmail, amount: parseInt(amt), trxid: trx });
            saveData(); alert("Request Sent!"); 
            document.getElementById('deposit-form').style.display = 'none';
        } else alert("সবগুলো ঘর পূরণ করুন!");
    }

    function submitWithdraw() {
        const amt = parseInt(document.getElementById('wit-amount').value);
        const num = document.getElementById('wit-number').value;
        const user = users.find(u => u.email === currentUserEmail);
        if(!amt || !num || !selectedWitMethod) return alert("সবগুলো ঘর পূরণ করুন!");
        if((user.mainBalance || 0) >= amt && amt >= 100) {
            user.mainBalance -= amt;
            witRequests.push({ userEmail: currentUserEmail, amount: amt, number: num, method: selectedWitMethod });
            saveData(); alert("Withdraw Request Sent!"); updateUI();
            document.getElementById('withdraw-form').style.display = 'none';
        } else alert("Insufficient Main Balance (Min 100)!");
    }

    function openAdminPanel() {
        if(prompt("PASSWORD:") === "462357") {
            showSection('admin-panel');
            document.getElementById('admin-music-url').value = musicConfig.url;
        }
    }

    function adminSetMusic(status) {
        const url = document.getElementById('admin-music-url').value.trim();
        if(status && !url) return alert("গানের লিঙ্ক দিন!");
        musicConfig = { isEnabled: status, url: url };
        localStorage.setItem('ludo_music_config', JSON.stringify(musicConfig));
        alert(status ? "মিউজিক চালু হয়েছে!" : "মিউজিক বন্ধ হয়েছে!");
        handleGlobalMusicSync();
    }

    function renderAdminData() {
        document.getElementById('user-list-body').innerHTML = users.map(u => `
            <tr>
                <td>${u.name}</td>
                <td>${u.email}</td>
                <td>৳${u.mainBalance || 0}</td>
                <td>
                    <button class="btn-sm btn-ban" onclick="adminToggleBan('${u.email}')">${u.isBanned ? 'Unban' : 'Ban'}</button>
                    <button class="btn-sm btn-del" onclick="adminDeleteUser('${u.email}')">Del</button>
                </td>
            </tr>`).join('');

        document.getElementById('deposit-request-body').innerHTML = depRequests.map((req, i) => `
            <tr><td>${req.userEmail}</td><td>${req.amount}</td><td>${req.trxid}</td>
            <td>
                <button class="btn-sm btn-paid" onclick="approveDeposit(${i})">OK</button>
                <button class="btn-sm btn-del" onclick="deleteDepositRequest(${i})">Del</button>
            </td></tr>`).join('');
        
        document.getElementById('withdraw-request-body').innerHTML = witRequests.map((req, i) => `
            <tr><td>${req.userEmail}</td><td>${req.amount}</td><td>${req.number}</td><td>${req.method}</td>
            <td>
                <button class="btn-sm btn-paid" onclick="approveWithdraw(${i})">Paid</button>
                <button class="btn-sm btn-del" onclick="deleteWithdrawRequest(${i})">Del</button>
            </td></tr>`).join('');

        document.getElementById('match-code-update-body').innerHTML = matches.map((m, i) => `
            <tr>
                <td>${m.name}</td>
                <td><input type="text" id="new-code-${m.id}" style="width:70px; padding:5px; margin:0; border-radius:5px;" value="${m.code}"></td>
                <td>
                    <button class="btn-sm btn-paid" onclick="updateMatchCode(${m.id})">Fix</button>
                    <button class="btn-sm btn-del" onclick="deleteMatch(${m.id})">Del</button>
                </td>
            </tr>`).join('');

        document.getElementById('admin-results-body').innerHTML = winResults.map((res, i) => {
            const uData = users.find(u => u.email === res.user);
            const uName = uData ? uData.name : "Unknown";
            return `
            <tr>
                <td><b>${uName}</b> <br> <small>${res.user}</small></td>
                <td>${res.match}</td>
                <td><a href="${res.img}" target="_blank"><img src="${res.img}" width="40"></a></td>
                <td><button class="btn-sm btn-del" onclick="deleteWinResult(${i})">Del</button></td>
            </tr>`;
        }).join('');
    }

    function deleteWinResult(i) {
        if(confirm("Delete this result?")) { winResults.splice(i, 1); saveData(); renderAdminData(); }
    }

    function deleteDepositRequest(index) {
        if(confirm("ডিলিট করতে চান?")) { depRequests.splice(index, 1); saveData(); renderAdminData(); }
    }

    function deleteWithdrawRequest(index) {
        if(confirm("ডিলিট করতে চান?")) { witRequests.splice(index, 1); saveData(); renderAdminData(); }
    }

    function adminToggleBan(email) {
        const user = users.find(u => u.email === email);
        if(user) { user.isBanned = !user.isBanned; saveData(); renderAdminData(); alert(user.isBanned ? "Banned" : "Unbanned"); }
    }

    function adminDeleteUser(email) {
        if(confirm("Delete User?")) { users = users.filter(u => u.email !== email); saveData(); renderAdminData(); }
    }

    function approveDeposit(index) {
        const req = depRequests[index];
        const user = users.find(u => u.email === req.userEmail);
        if(user) user.mainBalance = (user.mainBalance || 0) + req.amount;
        depRequests.splice(index, 1);
        saveData(); renderAdminData(); updateUI(); alert("Approved!");
    }

    function approveWithdraw(index) { witRequests.splice(index, 1); saveData(); renderAdminData(); }

    function updateMatchCode(matchId) {
        const newCode = document.getElementById(`new-code-${matchId}`).value;
        const match = matches.find(m => m.id === matchId);
        if(match) { match.code = newCode; saveData(); alert("Updated!"); updateUI(); }
    }

    function deleteMatch(matchId) {
        if(confirm("Delete Match?")) { matches = matches.filter(m => m.id !== matchId); saveData(); renderAdminData(); updateUI(); }
    }

    function adminUpdateNotice() {
        appNotice = document.getElementById('admin-notice-input').value;
        localStorage.setItem('ludo_app_notice', appNotice);
        document.getElementById('app-notice-text').innerText = appNotice;
        alert("Notice Updated!");
    }

    function adminUpdateDepNum() {
        depositNumber = document.getElementById('admin-dep-num-input').value;
        localStorage.setItem('ludo_deposit_num', depositNumber);
        alert("ডিপোজিট নাম্বার আপডেট হয়েছে!");
    }

    function adminManualAddBalance() {
        const email = document.getElementById('target-user-email').value.trim();
        const amt = parseInt(document.getElementById('manual-balance-amount').value);
        const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
        if(user && amt) {
            user.mainBalance = (user.mainBalance || 0) + amt;
            saveData(); updateUI(); renderAdminData(); alert("Balance Added!");
        } else alert("User not found!");
    }

    function adminAddMatch() {
        const name = document.getElementById('m-name').value;
        const fee = document.getElementById('m-fee').value;
        const prize = document.getElementById('m-prize').value;
        const code = document.getElementById('m-code').value;
        const limitText = document.getElementById('m-limit-text').value;
        if(name && fee) {
            matches.push({ id: Date.now(), name, fee: parseInt(fee), prize: parseInt(prize), code, limitText, playerEmails: [] });
            saveData(); alert("Match Added!"); updateUI();
        } else alert("সবগুলো তথ্য দিন!");
    }

    function updateUI() {
        const user = users.find(u => u.email === currentUserEmail);
        if(!user) return;
        document.getElementById('welcome-text').innerText = "স্বাগতম, " + user.name.toUpperCase() + "!";
        document.querySelectorAll('.m-bal-text').forEach(el => el.innerText = user.mainBalance || 0);
        document.querySelectorAll('.g-bal-text').forEach(el => el.innerText = user.gamingBalance || 0);
        
        const list = document.getElementById('match-list');
        list.innerHTML = matches.map((m, i) => {
            const hasJoined = user.joined && user.joined.includes(m.id);
            const joinedCount = m.playerEmails ? m.playerEmails.length : 0;
            const isFull = joinedCount >= 2;
            let btnHTML = hasJoined ? `<div class="room-code-box">CODE: ${m.code}</div>` : 
                          (isFull ? `<button class="btn-join full">MATCH FULL</button>` : `<button class="btn-join" onclick="joinMatch(${i})">JOIN NOW</button>`);

            return `<div class="match-card">
                <span class="match-name-tag">${m.name}</span>
                <div class="match-info-grid">
                    <div class="match-info-item"><span>Entry Fee</span><b>৳${m.fee}</b></div>
                    <div class="match-info-item"><span>Prize Pool</span><b>৳${m.prize}</b></div>
                </div>
                <div style="display:flex; justify-content:space-between; align-items:center; margin-top:10px;">
                    <p style="color:var(--danger); font-size:12px; font-weight:bold; margin:0;">${m.limitText}</p>
                    <p style="color:var(--accent); font-size:12px; font-weight:bold; margin:0;">Joined: ${joinedCount}/2</p>
                </div>
                ${btnHTML}
            </div>`;
        }).join('');
    }

    function joinMatch(index) {
        const user = users.find(u => u.email === currentUserEmail);
        const match = matches[index];
        if(match.playerEmails && match.playerEmails.length >= 2) return alert("Match Full!");
        if((user.gamingBalance || 0) >= match.fee) {
            user.gamingBalance -= match.fee;
            if(!user.joined) user.joined = [];
            user.joined.push(match.id);
            if(!match.playerEmails) match.playerEmails = [];
            match.playerEmails.push(currentUserEmail);
            saveData(); updateUI(); alert("Joined Match!");
        } else alert("Insufficient Gaming Balance!");
    }

    function saveData() {
        localStorage.setItem('ludo_users', JSON.stringify(users));
        localStorage.setItem('ludo_matches', JSON.stringify(matches));
        localStorage.setItem('ludo_dep_req', JSON.stringify(depRequests));
        localStorage.setItem('ludo_wit_req', JSON.stringify(witRequests));
        localStorage.setItem('ludo_win_results', JSON.stringify(winResults));
    }
